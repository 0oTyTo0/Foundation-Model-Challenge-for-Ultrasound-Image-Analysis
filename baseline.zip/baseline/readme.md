**IMPORTANT NOTE**
The evaluation method in the code is only used for saving models and has nothing to do with the official evaluation method.

**FILE OVERVIEW**

**dataset.py**
Implements the data loading logic. It includes the 'MultiTaskDataset' for loading images and labels from CSV files, and the 'MultiTaskUniformSampler' to ensure balanced sampling across different tasks (segmentation, classification, regression, detection) during training.

**model_factory.py**
Defines the model architecture. It uses an EfficientNet-B4 encoder with a shared FPN decoder. The 'MultiTaskModelFactory' class automatically initializes specific heads (e.g., SegmentationHead, FPNGridDetectionHead) for each task defined in the configuration.

**utils.py**
Contains helper functions and evaluation metrics. This file includes the custom 'DetectionLoss', the 'multi_task_collate_fn' for handling batch construction, and functions to calculate Dice, IoU, Accuracy, and MAE. It also holds the validation loop logic.

**train.py**
The main training script. It sets up the hyperparameters (learning rate, batch size), initializes the model and optimizer, and runs the training loop. It saves the model weights to 'best_model.pth' based on the internal validation score.

**USAGE INSTRUCTIONS**

1. Install the required libraries (torch, segmentation_models_pytorch, albumentations, pandas, opencv-python, scikit-learn).
2. Open 'train.py' and modify the 'DATA_ROOT_PATH' variable to point to your dataset directory.
3. Run the command: python train.py